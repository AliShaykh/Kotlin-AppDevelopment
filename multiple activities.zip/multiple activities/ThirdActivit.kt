package com.example.multiactivities_d

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class ThirdActivit : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_third)
        val act1:Button = findViewById(R.id.s1)
        val act2:Button = findViewById(R.id.s2)

        act1.setOnClickListener({
            startActivity(Intent(this, MainActivity::class.java))
        })
        act2.setOnClickListener({
            startActivity(Intent(this, SecondActivity::class.java))

        })



    }
}